import cv2
import numpy as np
from glob import glob
from math import atan, degrees
from datetime import datetime
from inria_qatm_pytorchv2_copy import *
import argparse
from skimage.draw import line
from noise import noise, blur
from cam_sim import SimCamera
import torchvision
from time import time,sleep
from cam_sim import SimCamera
import torch

#fourcc = cv2.VideoWriter_fourcc(*'MJPG')
#width = 100
#height = 100
FPS = 30
source_image_scale_factor = 1
video_file = f'inria_video/{datetime.now().strftime("_%d%m%Y_%H%M%S")}.avi'

select_points = True

# Add localized run function for spatial masking
def run_one_sample_2_localized(model, template, image, search_region=None):
    """Run template matching with optional spatial localization"""
    if hasattr(model, 'apply_spatial_mask') and search_region is not None:
        # Use localized version if available
        val = model(template, search_region=search_region)
    else:
        # Fallback to regular method
        val = model(template, image)
    
    if val.is_cuda:
        val = val.cpu()
    val = val.numpy()
    val = np.log(val)

    batch_size = val.shape[0]
    scores = []
    for i in range(batch_size):
        gray = val[i, :, :, 0]
        gray = cv2.resize(gray, (image.size()[-1], image.size()[-2]))
        h = template.size()[-2]
        w = template.size()[-1]
        score = compute_score(gray, w, h)
        score[score > -1e-7] = score.min()
        score = np.exp(score / (h * w))
        scores.append(score)
    return np.array(scores)

def mouse_click(event, x, y, flags, param):
    global scaled_image, points_array, source_image_scale_factor, line_draw_array, select_points
    if select_points:
        if event == cv2.EVENT_LBUTTONDOWN:
            cv2.circle(scaled_image, (x, y), 5, (0, 0, 255), 4)
            points_array.append([x * source_image_scale_factor, y * source_image_scale_factor])
            line_draw_array.append([x, y])
            if len(points_array) > 1:
                delta_x, delta_y = line_draw_array[-2][0] - line_draw_array[-1][0], line_draw_array[-2][1] - \
                                   line_draw_array[-1][1]
                ang = degrees(atan(delta_y / delta_x))
                print(line_draw_array[-2], line_draw_array[-1], ang)
                cv2.line(scaled_image, tuple(line_draw_array[-2]), tuple(line_draw_array[-1]), (0, 255, 255), 2)
            cv2.imshow("point_selector", scaled_image)

def rect_bbox2(rect):
    (center_x, center_y), (width, height), _ = rect
    x, y, w, h = int(center_x - width / 2), int(center_y - height / 2), int(width), int(height)
    return (x, y, x + w, y + h)

if __name__ == "__main__":

    parser = argparse.ArgumentParser(description='INRIA QATM Implementation')
    parser.add_argument('--cuda', action='store_true', default=False)
    parser.add_argument('--resize', '-r', type=int, default=100)
    parser.add_argument('--crop_size', '-cs', type=int, default=150)
    parser.add_argument('--alpha', '-a', type=float, default=25)
    parser.add_argument('--fps', '-f', type=int, default=5)
    parser.add_argument('--scale_factor', '-sf', type=int, default=1)
    parser.add_argument('--thres', '-t', type=float, default=0.7, help="threshold for QATM matching")
    parser.add_argument('--source', '-s', type=str)
    parser.add_argument('--noise', '-n', type=str, default='none',
                        help="Noise type {gauss_n, gauss_u, sp, poisson, random, none}")
    parser.add_argument('--blur', '-b', type=str, default='none',
                        help="blur type = {normal, median, gauss, bilateral, none}")
    parser.add_argument('--blur_filter', '-bf', type=int, default=5,
                        help="blur filter size, must be odd number")
    parser.add_argument('--local', '-l', action='store_true', default=False)
    parser.add_argument('--local_size', '-ls', type=int, default=300)
    args = parser.parse_args()
    print(args)
    
    width, height = args.crop_size, args.crop_size
    np.random.seed(123)
    source_image_scale_factor = args.scale_factor

    points_array = []
    line_draw_array = []
    template_resolution = (width, height)
    
    # Load source image
    source_image = cv2.imread(args.source)
    src_h, src_w = source_image.shape[:2]
    scaled_image = cv2.resize(source_image, (src_h * source_image_scale_factor, src_w * source_image_scale_factor))

    # Point selection interface
    cv2.imshow("point_selector", scaled_image)
    cv2.setMouseCallback('point_selector', mouse_click)
    cv2.waitKey()
    select_points = False
    cv2.destroyWindow("point_selector")
    print(points_array)

    # Load model
    model = torchvision.models.vgg19()
    model.load_state_dict(torch.load("./vgg19.pth"))
    model = model.eval()

    # Initialize data loader and model
    data_loader = ImageData(source_img=args.source, half=False, thres=args.thres)
    color_list = color_palette("hls", 1)
    color_list = list(map(lambda x: (int(x[0] * 255), int(x[1] * 255), int(x[2] * 255)), color_list))
    
    color = 0
    d_img = data_loader.image_raw.copy()
    new_size = (int(width * args.resize / 100.0), int(height * args.resize / 100.0))

    # Choose model based on localization flag
    if args.local:
        print("Using localized model with spatial masking...")
        model = CreateModel_Localized(model=model.features, alpha=args.alpha, use_cuda=args.cuda, image=data_loader.image)
    else:
        print("Using standard global model...")
        model = CreateModel_2(model=model.features, alpha=args.alpha, use_cuda=args.cuda, image=data_loader.image)

    # Initialize camera simulation
    camera_fps = args.fps
    camera = SimCamera(points_array=points_array, image=args.source, fps=camera_fps, skip_pts=3)
    camera.start()
    
    # Initialize localization variables
    prev_detection_center = None
    tic = time()

    # Main processing loop
    while True:
        if camera.frame_q.empty():
            print(time(), " Frame Q Empty")
            sleep(1/camera_fps)
            print(camera.running)

            if not camera.running.empty() and camera.process.is_alive():
                continue
            else:
                print("Camera closed. press any key in CV window to close.")
                break
                
        fid, frame_x, frame_y, crop = camera.frame_q.get()
        print(fid, " Frame used")
        
        # Apply noise and blur
        crop = noise(crop, args.noise)
        crop = blur(crop, args.blur, (args.blur_filter, args.blur_filter))

        # Apply resize on input video
        if args.resize != 100:
            crop = cv2.resize(crop, new_size)

        w_array = []
        h_array = []
        thresh_list = []

        # Pass the template to data loader
        data = data_loader.load_template(crop)

        # Calculate search region for localization
        search_region = None
        if args.local and prev_detection_center is not None and hasattr(model, 'I_feat'):
            # Get feature map dimensions
            feat_h, feat_w = model.I_feat.shape[2], model.I_feat.shape[3]
            img_h, img_w = data_loader.image_raw.shape[:2]
            
            # Scale from image coordinates to feature coordinates
            scale_x = feat_w / img_w
            scale_y = feat_h / img_h
            
            # Calculate center in feature map coordinates
            center_x_feat = int(prev_detection_center[0] * scale_x)
            center_y_feat = int(prev_detection_center[1] * scale_y)
            
            # Calculate search window size in feature coordinates
            half_size = int(args.local_size * min(scale_x, scale_y) / 2)
            
            # Define search region bounds
            x1 = max(0, center_x_feat - half_size)
            y1 = max(0, center_y_feat - half_size)
            x2 = min(feat_w, center_x_feat + half_size)
            y2 = min(feat_h, center_y_feat + half_size)
            
            search_region = (x1, y1, x2, y2)
            print(f"Localized search region: {search_region}")

        # Run template matching (localized if applicable)
        if args.local and hasattr(model, 'apply_spatial_mask'):
            score = run_one_sample_2_localized(model, template=data['template'], 
                                              image=data['image'], search_region=search_region)
        else:
            score = run_one_sample_2(model, template=data['template'], image=data['image'])
            
        scores = np.squeeze(np.array([score]), axis=1)
        w_array.append(data['template_w'])
        w_array = np.array(w_array)
        h_array.append(data['template_h'])
        h_array = np.array(h_array)
        thresh_list.append(data['thresh'])

        # Apply NMS and threshold on the results of QATM
        mb_boxes, mb_indices = nms_multi(scores, w_array, h_array, thresh_list, multibox=True)

        if len(mb_indices) > 0:
            # Update previous detection center for next frame
            best_box = mb_boxes[0][0]
            prev_detection_center = (
                int((best_box[0][0] + best_box[1][0]) / 2),
                int((best_box[0][1] + best_box[1][1]) / 2)
            )
            
            # Plot result
            d_img = plot_result(scaled_image, mb_boxes[0][None, :, :], text=f"{fid}", text_loc=(frame_x-20, frame_y-20))
            scaled_image = d_img

        # Display results
        cv2.imshow("result", cv2.resize(d_img, (d_img.shape[1] // source_image_scale_factor,
                                                d_img.shape[0] // source_image_scale_factor)))
        cv2.imshow("v-camera", crop)
        
        k = cv2.waitKey(1)
        if k == ord('q'):
            break
            
        toc = time()
        print("Time taken: ", toc - tic)
        tic = toc
        
    cv2.waitKey()