# inria_qatm_pytorchv2_copy.py

**Adds a new `CreateModel_Localized` class extending `CreateModel_2` with an `apply_spatial_mask` method.**

```python
import torch
import torch.nn.functional as F
from torchvision import transforms
from utils import MyNormLayer_new, Featex, QATM

class CreateModel_Localized:
    def __init__(self, model, alpha, use_cuda, image_tensor):
        self.alpha = alpha
        self.featex = Featex(model, use_cuda, save_features=True)
        # Precompute features for the full image
        self.I_feat = self.featex(image_tensor)  # [1, C, H, W]
        self.I_feat_norm = MyNormLayer_new(self.I_feat)
        self.I_feat_torch_norm = torch.norm(self.I_feat_norm, dim=1, keepdim=True)

    def __call__(self, template_tensor, search_region=None):
        # Extract and normalize template features
        T_feat = self.featex(template_tensor)
        batchsize_T = T_feat.size(0)
        conf_maps = []
        for i in range(batchsize_T):
            t = T_feat[i : i+1]
            t_norm = MyNormLayer_new(t)
            t_tnorm = torch.norm(t_norm, dim=1, keepdim=True)
            # Cosine similarity over spatial dims
            dist = torch.einsum(
                "xcab,xcde->xabde",
                self.I_feat_norm.div(self.I_feat_torch_norm),
                t_norm.div(t_tnorm),
            )
            conf = QATM(self.alpha)(dist)  # [1, H, W]
            if search_region is not None:
                conf = self.apply_spatial_mask(conf, search_region)
            conf_maps.append(conf)
        return torch.cat(conf_maps, dim=0)  # [batchsize_T, H, W]

    @staticmethod
    def apply_spatial_mask(conf_map, region):
        # region = (x1, y1, x2, y2) in feature-map coords
        x1, y1, x2, y2 = region
        mask = torch.zeros_like(conf_map)
        mask[:, y1:y2, x1:x2] = 1
        return conf_map * mask
```

---

## CURRENT APPROACH (Without Localization)

**What happens:**

- **Global image features computed:** *ONCE at startup*
- For each frame:
  - Extract template features from current crop
  - Compare template features against *ALL* cached global image features
  - Generate confidence map for *ENTIRE* image
  - Find best match anywhere in the image

**Feature extraction count per frame:**
- Global image: 1 time (init)
- Template: 1 time
- **Total:** 1 feature extraction


## NEW SPATIAL MASKING APPROACH (With Localization)

**What changes:**

- Global image features computed: ONCE at startup (unchanged)
- For each frame:
  - Extract template features from current crop
  - Compare template features against *ALL* cached global image features
  - Generate confidence map for *ENTIRE* image
  - **NEW:** Apply spatial mask to zero out values outside search window
  - Find best match only within masked region

**Feature extraction count per frame:** same as before (1)

**Key Point:** *No additional feature extraction*. Only post-processing differs.


### Why it's faster

- **Reduced NMS processing:** Fewer peaks to process since most are zeroed out
- **Faster peak finding:** Smaller search space
- **Better tracking:** Eliminates distant false positives

**Speed benefit** comes from reduced post-processing, *not* from reduced feature extraction.


| Aspect                          | Current Approach              | Spatial Masking Approach            |
|---------------------------------|-------------------------------|-------------------------------------|
| Global image feature extraction | 1 time at startup            | 1 time at startup ✓                |
| Template feature extraction     | 1 time per frame             | 1 time per frame ✓                 |
| Similarity computation          | Full image                   | Full image ✓                       |
| Search consideration            | Entire confidence map        | Only masked region                |
| Speed benefit                   | None                         | From reduced post-processing      |


**Real Benefit:**

- **Tracking accuracy:** Remains near previous detection
- **Eliminates false matches:** From distant regions
- **Slightly faster post-processing:** Less area to analyze


---

# inria_test_v2_updated.py

**Introduces interlocking components to enable optional localized matching via spatial masking.**

## New Command-Line Flags

- `--local (-l)`: Boolean switch to enable localization
- `--local_size (-ls)`: Integer side length (pixels) of the square search window

## Two Matching Routines

1. **Global matching**: Uses original `CreateModel_2` and `run_one_sample_2` (full-image caching and similarity).
2. **Localized matching**: Uses new `run_one_sample_2_localized`:
   - Checks for `search_region`; if present, calls `model(template, search_region=…)`
   - Falls back to global if no region or model lacks masking


## Conditional Model Instantiation

```python
if args.local:
    model = CreateModel_Localized(...)
else:
    model = CreateModel_2(...)
```

- Localization disabled: original pipeline
- Localization enabled: wraps VGG19 backbone with spatial masking

## Tracking the Last Detection Center

```python
prev_detection_center = None
# After NMS, compute and store center for next frame
```

## Converting Image → Feature-Map Coordinates

```python
feat_h, feat_w = model.I_feat.shape[2:]
img_h, img_w = data_loader.image_raw.shape[:2]
scale_x, scale_y = feat_w/img_w, feat_h/img_h
cx_feat = int(prev_center[0] * scale_x)
cy_feat = int(prev_center[1] * scale_y)
```

## Defining the Search Window

```python
half = int(args.local_size * min(scale_x, scale_y) / 2)
x1 = max(0, cx_feat - half)
x2 = min(feat_w, cx_feat + half)
y1 = max(0, cy_feat - half)
y2 = min(feat_h, cy_feat + half)
search_region = (x1, y1, x2, y2)
```

Passed to `run_one_sample_2_localized` for masking.

## Spatial Masking Inside the Model

- Computes global confidence map as before
- Builds binary mask of same size, sets ones inside region
- Multiplies confidence map by mask to zero out outside scores

## Unified Display and Timing

All other loop logic (noise, resizing, NMS, plotting, timing) remains unchanged for seamless integration.
